------------------------------------------------------------------------------------
--                    Cmod S6 Register I/O Demonstration Project                  --
------------------------------------------------------------------------------------

The Cmod S6 demonstration project includes the source files necessary to create
a connection between the Cmod S6 and the Digilent Adept runtime application to 
manipulate the I/O registers. The behavior is as follows:

    *LD2 and LD3 toggle back and forth at approximately 1 Hz.
    *LD0 and LD1 toggles with BTN0 and BTN1 respectively.
    *Pins 1-23 and 26-48 are controlled through the Adept application. The Cmod S6
     reference manual specifies this functionality.

Create a Xilinx project using the provided source files and generate a programmable
file targeted at the XCL6SLX4-2CPG196 FPGA. For more detailed information on the
Cmod S6, please refer to the reference manual available on digilentinc.com.

Binaries are also included that can be used to program the FPGA (.bit) and the SPI
Flash (.mcs) directly using iMPACT.